from flask import Flask, render_template, request, redirect, url_for, session, flash
from functools import wraps
from datetime import datetime
from werkzeug.utils import secure_filename
import os
from db_config import get_db_connection

app = Flask(__name__)
app.secret_key = 'change_this_secret_key_12345'

# Ensure upload folder exists
UPLOAD_FOLDER = os.path.join('static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Define allowed extensions for file upload security
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def execute_query(query, params=None, fetch=False, fetch_one=False):
    """Execute a database query with error handling"""
    conn = get_db_connection()
    if conn is None:
        flash('Database connection error. Please try again later.', 'danger')
        return None
    
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(query, params or ())
        
        if fetch_one:
            result = cursor.fetchone()
        elif fetch:
            result = cursor.fetchall()
        else:
            conn.commit()
            result = cursor.lastrowid
        
        cursor.close()
        conn.close()
        return result
    except Exception as e:
        print(f"Database error: {e}")
        if conn:
            conn.close()
        return None

def ensure_gender_column_exists():
    """Ensure the gender column exists in the pets table"""
    try:
        # Check if column exists by trying to describe the table
        conn = get_db_connection()
        if conn is None:
            return False
        
        cursor = conn.cursor(dictionary=True)
        cursor.execute("DESCRIBE pets")
        columns = cursor.fetchall()
        column_names = [col['Field'] for col in columns]
        
        if 'gender' not in column_names:
            # Add the gender column
            alter_query = """
                ALTER TABLE pets 
                ADD COLUMN gender ENUM('male', 'female') NOT NULL DEFAULT 'male'
            """
            cursor.execute(alter_query)
            conn.commit()
            print("Gender column added to pets table")
        
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error ensuring gender column exists: {e}")
        if conn:
            conn.close()
        return False

# Ensure gender column exists on startup
ensure_gender_column_exists()

# Decorators for role management
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session or session.get('role') != 'admin':
            flash('Access denied: Admins only.', 'danger')
            return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated_function

def add_notification(username, message, notif_type='info'):
    query = """
        INSERT INTO notifications (username, message, type, created_at, is_read)
        VALUES (%s, %s, %s, NOW(), FALSE)
    """
    execute_query(query, (username, message, notif_type))

# Context Processor
@app.context_processor
def inject_notifications():
    if 'username' in session and session['role'] == 'user':
        query = "SELECT COUNT(*) as count FROM notifications WHERE username = %s AND is_read = FALSE"
        result = execute_query(query, (session['username'],), fetch_one=True)
        unread_count = result['count'] if result else 0
        return dict(unread_notifications=unread_count)
    return dict(unread_notifications=0)

# Routes
@app.route('/')
def home():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('home.html', title="FurEver Home", tagline="Find Your New Best Friend")

@app.route('/about')
@login_required
def about():
    context = {
        'mission': 'Our mission is to connect loving families with pets in need, ensuring every animal finds a safe and happy forever home.',
        'services': [
            'Comprehensive Pet Profiles',
            'Adoption Counseling',
            'Post-Adoption Support',
            'Veterinary Referrals',
            'Community Events'
        ]
    }
    return render_template('about.html', **context)

@app.route('/contact')
@login_required
def contact():
    context = {
        'contact_info': {
            'phone': '(555) 123-4567',
            'email': 'support@fureverhome.com',
        }
    }
    return render_template('contact.html', **context)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        query = "SELECT * FROM users WHERE username = %s AND password = %s"
        user = execute_query(query, (username, password), fetch_one=True)
        
        if user:
            session['username'] = user['username']
            session['role'] = user['role']
            session['name'] = user['name']
            flash(f'Welcome, {session["name"]}!', 'success')
            if session['role'] == 'admin':
                return redirect(url_for('admin_dashboard'))
            next_page = request.args.get('next') or request.form.get('next') or url_for('home')
            return redirect(next_page)
        else:
            flash('Invalid username or password.', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        name = request.form['name']
        email = request.form['email']
        contact_number = request.form.get('contact_number')
        
        check_query = "SELECT username FROM users WHERE username = %s"
        existing_user = execute_query(check_query, (username,), fetch_one=True)
        
        if existing_user:
            flash('Username already exists.', 'warning')
        else:
            insert_query = """
                INSERT INTO users (username, password, role, name, email, contact_number, created_at)
                VALUES (%s, %s, 'user', %s, %s, %s, NOW())
            """
            result = execute_query(insert_query, (username, password, name, email, contact_number))
            
            if result:
                flash('Registration successful! Please log in.', 'success')
                return redirect(url_for('login'))
            else:
                flash('Registration failed. Please try again.', 'danger')
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    session.pop('username', None)
    session.pop('role', None)
    session.pop('name', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/pets')
@login_required
def pets():
    query = "SELECT * FROM pets WHERE status = 'available' ORDER BY created_at DESC"
    available_pets = execute_query(query, fetch=True) or []
    return render_template('pets.html', pets=available_pets)

@app.route('/adopt/<int:pet_id>', methods=['GET', 'POST'])
@login_required
def adopt_pet(pet_id):
    query = "SELECT * FROM pets WHERE id = %s"
    pet = execute_query(query, (pet_id,), fetch_one=True)

    if not pet:
        flash('Pet not found.', 'danger')
        return redirect(url_for('pets'))
    
    if pet['status'] != 'available':
        flash(f"{pet['name']} is no longer available for adoption.", 'warning')
        return redirect(url_for('pets'))
    
    if session.get('role') == 'admin':
        flash('Admins cannot submit adoption requests.', 'warning')
        return redirect(url_for('pets'))

    if request.method == 'POST':
        contact_number = request.form.get('contact_number')
        address = request.form.get('address')
        message = request.form.get('message')
        residence_type = request.form.get('residence_type')
        pet_history = request.form.get('pet_history')
        time_alone = request.form.get('time_alone')

        user_query = "SELECT email FROM users WHERE username = %s"
        user_data = execute_query(user_query, (session['username'],), fetch_one=True)
        user_email = user_data['email'] if user_data else 'N/A'

        insert_query = """
            INSERT INTO adoption_requests 
            (pet_id, pet_name, username, applicant_name, email, contact_number, 
             address, message, residence_type, pet_history, time_alone, status, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'pending', NOW())
        """
        result = execute_query(insert_query, (
            pet_id, pet['name'], session['username'], session['name'], user_email,
            contact_number, address, message, residence_type, pet_history, time_alone
        ))
        
        if result:
            add_notification('admin', f"New adoption request for {pet['name']} from {session['name']}.", 'success')
            flash(f'Your adoption application for {pet["name"]} has been submitted!', 'success')
        else:
            flash('Failed to submit adoption request. Please try again.', 'danger')
            
        return redirect(url_for('pets'))

    return render_template('adopt_form.html', pet=pet)

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    total_pets_query = "SELECT COUNT(*) as count FROM pets"
    available_pets_query = "SELECT COUNT(*) as count FROM pets WHERE status = 'available'"
    pending_requests_query = "SELECT COUNT(*) as count FROM adoption_requests WHERE status = 'pending'"
    
    total_pets = execute_query(total_pets_query, fetch_one=True)['count']
    available_pets = execute_query(available_pets_query, fetch_one=True)['count']
    pending_requests = execute_query(pending_requests_query, fetch_one=True)['count']
    
    adoption_requests = execute_query("SELECT * FROM adoption_requests ORDER BY created_at DESC", fetch=True) or []
    pets_db = execute_query("SELECT * FROM pets ORDER BY created_at DESC", fetch=True) or []
    users_list = execute_query("SELECT username, name, email, role, contact_number FROM users", fetch=True) or []
    users = {user['username']: user for user in users_list}
    
    context = {
        'total_pets': total_pets,
        'available_pets': available_pets,
        'pending_requests': pending_requests,
        'adoption_requests': adoption_requests,
        'pets_db': pets_db,
        'users': users
    }
    return render_template('admin_dashboard.html', **context)

@app.route('/admin/requests/<int:request_id>/<action>')
@admin_required
def manage_request(request_id, action):
    req_query = "SELECT * FROM adoption_requests WHERE id = %s"
    req = execute_query(req_query, (request_id,), fetch_one=True)
    
    if not req:
        flash('Adoption request not found.', 'danger')
        return redirect(url_for('admin_dashboard'))

    pet_query = "SELECT * FROM pets WHERE id = %s"
    pet = execute_query(pet_query, (req['pet_id'],), fetch_one=True)
    
    if action == 'approve':
        if pet and pet['status'] == 'available':
            update_req = "UPDATE adoption_requests SET status = 'approved' WHERE id = %s"
            update_pet = "UPDATE pets SET status = 'adopted' WHERE id = %s"
            
            execute_query(update_req, (request_id,))
            execute_query(update_pet, (req['pet_id'],))
            
            flash(f'Adoption request for {req["pet_name"]} approved!', 'success')
            add_notification(req['username'], f'Your adoption request for {req["pet_name"]} has been APPROVED!', 'success')
        else:
            flash(f'Cannot approve: {req["pet_name"]} is already adopted or unavailable.', 'warning')
            
    elif action == 'reject':
        update_query = "UPDATE adoption_requests SET status = 'rejected' WHERE id = %s"
        execute_query(update_query, (request_id,))
        
        flash(f'Adoption request for {req["pet_name"]} rejected.', 'danger')
        add_notification(req['username'], f'Your adoption request for {req["pet_name"]} has been REJECTED.', 'danger')
        
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/pets/add', methods=['GET', 'POST'])
@admin_required
def add_pet():
    if request.method == 'POST':
        # File Upload Handling
        file = request.files.get('file')
        filename = 'default_pet.jpg'

        if file and file.filename:
            if allowed_file(file.filename):
                secure_name = secure_filename(file.filename)
                timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                filename = f"{timestamp}_{secure_name}"
                file.save(os.path.join(UPLOAD_FOLDER, filename))
            else:
                flash("Invalid file type. Only images (png, jpg, jpeg, gif) are allowed.", 'danger')
                return redirect(url_for('add_pet'))

        gender_value = request.form.get('gender')
        if not gender_value:
            flash('Please select a gender for the pet.', 'danger')
            return redirect(url_for('add_pet'))
        
        insert_query = """
            INSERT INTO pets (name, breed, age, gender, description, status, image, created_at)
            VALUES (%s, %s, %s, %s, %s, 'available', %s, NOW())
        """
        result = execute_query(insert_query, (
            request.form.get('name'),
            request.form.get('breed'),
            request.form.get('age'),
            gender_value,
            request.form.get('description'),
            filename
        ))
        
        if result:
            flash(f'{request.form.get("name")} added successfully!', 'success')
        else:
            flash('Failed to add pet. Please check that the gender column exists in the database.', 'danger')
            
        return redirect(url_for('admin_dashboard'))
    return render_template('add_pet.html')

@app.route('/admin/pets/delete/<int:pet_id>')
@admin_required
def delete_pet(pet_id):
    pet_query = "SELECT name FROM pets WHERE id = %s"
    pet = execute_query(pet_query, (pet_id,), fetch_one=True)
    
    if pet:
        delete_query = "DELETE FROM pets WHERE id = %s"
        execute_query(delete_query, (pet_id,))
        flash(f'{pet["name"]} removed successfully!', 'success')
    else:
        flash('Pet not found.', 'danger')
        
    return redirect(url_for('admin_dashboard'))

@app.route('/notifications')
@login_required
def view_notifications():
    if session.get('role') == 'admin':
        flash('Admins do not have personal notifications.', 'info')
        return redirect(url_for('admin_dashboard'))
    
    query = """
        SELECT * FROM notifications 
        WHERE username = %s 
        ORDER BY created_at DESC
    """
    user_notifications = execute_query(query, (session['username'],), fetch=True) or []
    
    update_query = "UPDATE notifications SET is_read = TRUE WHERE username = %s AND is_read = FALSE"
    execute_query(update_query, (session['username'],))

    return render_template('notifications.html', notifications=user_notifications)

@app.route('/notifications/read/<int:notif_id>')
@login_required
def mark_notification_read(notif_id):
    query = "UPDATE notifications SET is_read = TRUE WHERE id = %s AND username = %s"
    execute_query(query, (notif_id, session['username']))
    return redirect(url_for('view_notifications'))

if __name__ == '__main__':
    app.run(debug=True)
