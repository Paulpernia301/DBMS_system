"""
Image Downloader for FurEver Home Pet Adoption System
This script downloads placeholder images for testing purposes.
For production, replace with actual pet photos.
"""

import urllib.request
import os
import time

def download_images():
    # Create uploads directory if it doesn't exist
    uploads_dir = os.path.join('static', 'uploads')
    os.makedirs(uploads_dir, exist_ok=True)
    
    print("=" * 60)
    print("FurEver Home - Image Downloader")
    print("=" * 60)
    print()
    
    # Images to download with placeholder service
    images = {
        'home_bg.jpg': 'https://i.pinimg.com/1200x/b0/a9/67/b0a967830ce49ecf0c9e4a1c23033db8.jpg',
        'luna.jpg': 'https://i.pinimg.com/1200x/bb/97/2b/bb972b8084e2c84ff4abd257f05ccf33.jpg',
        'shadow.jpg': 'https://i.pinimg.com/736x/23/b8/5f/23b85f60a027830aab881d980071bee1.jpg',
        'max.jpg': 'https://i.pinimg.com/1200x/1b/0b/35/1b0b358460bbdb44640a6238ad8aa8fb.jpg',
        'bella.jpg': 'https://i.pinimg.com/736x/40/94/bd/4094bd24cf64b47844a054a00633fab8.jpg',
        'charlie.jpg': 'https://i.pinimg.com/736x/72/eb/a2/72eba27aa7d23faee392850af8107a86.jpg',
        'milo.jpg': 'https://i.pinimg.com/736x/88/17/76/8817766ac162223c90892b1afcd9784c.jpg',
    }
    
    total = len(images)
    success = 0
    failed = []
    
    for i, (filename, url) in enumerate(images.items(), 1):
        filepath = os.path.join(uploads_dir, filename)
        
        # Skip if file already exists
        if os.path.exists(filepath):
            print(f"[{i}/{total}] ⏭️  Skipping {filename} (already exists)")
            success += 1
            continue
        
        try:
            print(f"[{i}/{total}] 📥 Downloading {filename}...", end=' ')
            urllib.request.urlretrieve(url, filepath)
            print("✅ Done!")
            success += 1
            time.sleep(0.5)  # Be nice to the server
        except Exception as e:
            print(f"❌ Failed!")
            failed.append((filename, str(e)))
    
    print()
    print("=" * 60)
    print(f"Download Summary:")
    print(f"  ✅ Successful: {success}/{total}")
    if failed:
        print(f"  ❌ Failed: {len(failed)}/{total}")
        print()
        print("Failed downloads:")
        for filename, error in failed:
            print(f"    - {filename}: {error}")
    print("=" * 60)
    print()
    
    if success == total:
        print("🎉 All images downloaded successfully!")
        print()
        print("Next steps:")
        print("  1. Replace placeholder images with actual pet photos")
        print("  2. Ensure images are named correctly:")
        print("     - luna.jpg, shadow.jpg, max.jpg, bella.jpg, charlie.jpg, milo.jpg")
        print("  3. Run your Flask app: python app.py")
    else:
        print("⚠️  Some images failed to download.")
        print("Please download them manually or try again.")
    
    print()
    print("📁 Images location:", os.path.abspath(uploads_dir))
    print()

def verify_images():
    """Verify all required images exist"""
    uploads_dir = os.path.join('static', 'uploads')
    
    if not os.path.exists(uploads_dir):
        print(f"❌ Directory not found: {uploads_dir}")
        return False
    
    required_images = [
        'home_bg.jpg', 'luna.jpg', 'shadow.jpg', 'max.jpg',
        'bella.jpg', 'charlie.jpg', 'milo.jpg'
    ]
    
    missing = []
    for img in required_images:
        filepath = os.path.join(uploads_dir, img)
        if not os.path.exists(filepath):
            missing.append(img)
    
    if missing:
        print(f"❌ Missing images: {', '.join(missing)}")
        return False
    
    print("✅ All required images are present!")
    return True

if __name__ == '__main__':
    try:
        print()
        print("Choose an option:")
        print("  1. Download all images (placeholder)")
        print("  2. Verify existing images")
        print()
        choice = input("Enter choice (1 or 2): ").strip()
        print()
        
        if choice == '1':
            download_images()
        elif choice == '2':
            verify_images()
        else:
            print("Invalid choice. Please run again and select 1 or 2.")
    
    except KeyboardInterrupt:
        print("\n\n⚠️  Download cancelled by user.")
    except Exception as e:
        print(f"\n❌ An error occurred: {e}")
        print("Please check your internet connection and try again.")
