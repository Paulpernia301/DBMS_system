# FurEver Home - MySQL Database Setup Guide

## Prerequisites

1. MySQL Server installed (version 5.7 or higher recommended)
2. Python 3.8 or higher
3. pip package manager

## Installation Steps

### 1. Install MySQL Server

**Windows:**
- Download MySQL Installer from [mysql.com](https://dev.mysql.com/downloads/installer/)
- Run installer and follow setup wizard
- Remember your root password

**macOS:**
\`\`\`bash
brew install mysql
brew services start mysql
\`\`\`

**Linux (Ubuntu/Debian):**
\`\`\`bash
sudo apt update
sudo apt install mysql-server
sudo systemctl start mysql
\`\`\`

### 2. Install Python Dependencies

\`\`\`bash
pip install -r requirements.txt
\`\`\`

Or install individually:
\`\`\`bash
pip install Flask mysql-connector-python Werkzeug python-dotenv
\`\`\`

### 3. Configure Database Connection

1. Copy `.env.example` to `.env`:
\`\`\`bash
cp .env.example .env
\`\`\`

2. Edit `.env` and update with your MySQL credentials:
\`\`\`env
DB_HOST=localhost
DB_PORT=3306
DB_NAME=furever_home
DB_USER=root
DB_PASSWORD=your_mysql_password
\`\`\`

### 4. Initialize the Database

**Option 1: Using Python Script**
\`\`\`bash
python db_config.py
\`\`\`

**Option 2: Using MySQL Command Line**
\`\`\`bash
mysql -u root -p < scripts/furever_home.sql
\`\`\`

**Option 3: Using MySQL Workbench**
1. Open MySQL Workbench
2. Connect to your MySQL server
3. File → Open SQL Script
4. Select `scripts/furever_home.sql`
5. Execute the script (⚡ lightning bolt icon)

### 5. Verify Database Setup

\`\`\`bash
python db_config.py
\`\`\`

You should see:
\`\`\`
Testing MySQL connection...
Successfully connected to MySQL Server version X.X.X
Connected to database: furever_home

Initializing database...
Database initialized successfully!
\`\`\`

## Database Schema

### Tables Created:

1. **users** - User accounts (admin and regular users)
2. **pets** - Pet information and adoption status
3. **adoption_requests** - Adoption applications from users
4. **notifications** - User notifications

### Default Data:

**Users:**
- Admin: username=`admin`, password=`admin123`
- User: username=`user`, password=`user123`

**Pets:** 6 sample pets (Luna, Shadow, Max, Bella, Charlie, Milo)

## Integration with Flask App

To integrate the MySQL database with your Flask application:

1. Import the database module:
\`\`\`python
from db_config import get_db_connection
\`\`\`

2. Use the connection in your routes:
\`\`\`python
@app.route('/example')
def example():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM pets WHERE status = 'available'")
    pets = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('example.html', pets=pets)
\`\`\`

## Troubleshooting

### Connection Refused
- Ensure MySQL server is running: `sudo systemctl status mysql`
- Check if MySQL is listening on port 3306: `netstat -an | grep 3306`

### Access Denied
- Verify credentials in `.env` file
- Reset MySQL root password if forgotten

### Database Not Found
- Run the initialization script again
- Manually create database: `CREATE DATABASE furever_home;`

### Import Errors
- Make sure all dependencies are installed: `pip install -r requirements.txt`
- Check Python version: `python --version` (should be 3.8+)

## SQL File Export Location

The complete SQL schema is available at: `scripts/furever_home.sql`

You can:
- Import it into any MySQL server
- Share it with team members
- Use it for deployment to production
- Modify it for custom requirements

## Next Steps

1. Change default passwords in production
2. Configure proper user permissions
3. Set up database backups
4. Consider using connection pooling for better performance
5. Implement password hashing (bcrypt) for security
