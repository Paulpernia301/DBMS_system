-- FurEver Home Database Schema
-- MySQL Database Setup Script

-- Create database
CREATE DATABASE IF NOT EXISTS furever_home;
USE furever_home;

-- Drop existing tables if they exist (for clean setup)
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS adoption_requests;
DROP TABLE IF EXISTS pets;
DROP TABLE IF EXISTS users;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    contact_number VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Pets table
CREATE TABLE pets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    breed VARCHAR(100) NOT NULL,
    age VARCHAR(50) NOT NULL,
    gender ENUM('male', 'female') NOT NULL,
    description TEXT,
    status ENUM('available', 'adopted', 'pending') DEFAULT 'available',
    image VARCHAR(255) DEFAULT 'default_pet.jpg',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Adoption requests table
CREATE TABLE adoption_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pet_id INT NOT NULL,
    pet_name VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL,
    applicant_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    contact_number VARCHAR(20) NOT NULL,
    address TEXT NOT NULL,
    message TEXT,
    residence_type VARCHAR(100),
    pet_history TEXT,
    time_alone VARCHAR(100),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE,
    FOREIGN KEY (username) REFERENCES users(username) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_username (username),
    INDEX idx_pet_id (pet_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notifications table
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info', 'success', 'warning', 'danger') DEFAULT 'info',
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES users(username) ON DELETE CASCADE,
    INDEX idx_username (username),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert only admin user as default
INSERT INTO users (username, password, role, name, email, contact_number) VALUES
('admin', 'admin123', 'admin', 'Administrator', 'admin@furever.com', NULL);

-- Insert sample pets
INSERT INTO pets (name, breed, age, gender, description, status, image) VALUES
('Luna', 'Orange Tabby', '2 years', 'female', 'Elegant and gentle companion.', 'available', 'luna.jpg'),
('Shadow', 'German Shepherd', '1 year', 'male', 'Sophisticated feline.', 'available', 'shadow.jpg'),
('Max', 'Siamese Cat', '3 years', 'male', 'Noble protector.', 'available', 'max.jpg'),
('Bella', 'Golden Retriever', '2 years', 'female', 'Playful and energetic.', 'available', 'bella.jpg'),
('Charlie', 'Beagle Dog', '1 year', 'male', 'Grace personified.', 'available', 'charlie.jpg'),
('Milo', 'Persian Cat', '2 years', 'male', 'Very vocal and affectionate.', 'available', 'milo.jpg');

-- Create views for common queries
CREATE OR REPLACE VIEW available_pets AS
SELECT * FROM pets WHERE status = 'available';

CREATE OR REPLACE VIEW pending_adoption_requests AS
SELECT 
    ar.*,
    p.name AS pet_name,
    p.image AS pet_image
FROM adoption_requests ar
JOIN pets p ON ar.pet_id = p.id
WHERE ar.status = 'pending';

CREATE OR REPLACE VIEW user_notifications_unread AS
SELECT 
    username,
    COUNT(*) AS unread_count
FROM notifications
WHERE is_read = FALSE
GROUP BY username;

-- Success message
SELECT 'Database furever_home created successfully!' AS message;
