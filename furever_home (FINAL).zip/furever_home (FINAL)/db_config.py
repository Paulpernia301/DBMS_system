"""
MySQL Database Configuration for FurEver Home
"""
import mysql.connector
from mysql.connector import Error
import os

DB_CONFIG = {
    'host': 'localhost',
    'port': 3306,
    'database': 'furever_home',
    'user': 'root',
    'password': '',  # Update with your MySQL root password
    'charset': 'utf8mb4',
    'use_unicode': True,
    'autocommit': False
}

def get_db_connection():
    """
    Create and return a database connection.
    Returns None if connection fails.
    """
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        if connection.is_connected():
            return connection
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

def init_db():
    """
    Initialize the database by running the SQL schema file.
    """
    try:
        connection = mysql.connector.connect(
            host=DB_CONFIG['host'],
            port=DB_CONFIG['port'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password']
        )
        
        if connection.is_connected():
            cursor = connection.cursor()
            
            # Read and execute SQL file
            with open('scripts/furever_home.sql', 'r', encoding='utf-8') as sql_file:
                sql_script = sql_file.read()
                
                # Split by semicolon and execute each statement
                statements = sql_script.split(';')
                for statement in statements:
                    statement = statement.strip()
                    if statement:
                        try:
                            cursor.execute(statement)
                        except Error as e:
                            print(f"Error executing statement: {e}")
                            print(f"Statement: {statement[:100]}...")
            
            connection.commit()
            print("Database initialized successfully!")
            
            cursor.close()
            connection.close()
            return True
            
    except Error as e:
        print(f"Error initializing database: {e}")
        return False

def test_connection():
    """
    Test database connection and print status.
    """
    connection = get_db_connection()
    if connection:
        if connection.is_connected():
            db_info = connection.get_server_info()
            cursor = connection.cursor()
            cursor.execute("SELECT DATABASE();")
            record = cursor.fetchone()
            print(f"Successfully connected to MySQL Server version {db_info}")
            print(f"Connected to database: {record[0]}")
            cursor.close()
            connection.close()
            return True
    else:
        print("Failed to connect to MySQL database")
        return False

if __name__ == '__main__':
    print("Testing MySQL connection...")
    if test_connection():
        print("\nInitializing database...")
        init_db()
